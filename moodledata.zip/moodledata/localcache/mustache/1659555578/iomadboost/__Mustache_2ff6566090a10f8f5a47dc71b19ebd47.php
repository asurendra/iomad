<?php

class __Mustache_2ff6566090a10f8f5a47dc71b19ebd47 extends Mustache_Template
{
    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $buffer = '';

        $buffer .= $indent . '<div class="mt-4">
';
        $buffer .= $indent . '    <div class="mb-4">
';
        $buffer .= $indent . '        <div class="mx-auto bg-white" style="height: 25px; width: 100px"></div>
';
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . '    <div class="d-flex flex-column p-2 bg-white rounded mb-2">
';
        $buffer .= $indent . '        <div class="d-flex align-items-center mb-2">
';
        $buffer .= $indent . '            <div class="mr-2">
';
        $buffer .= $indent . '                <div class="rounded-circle bg-pulse-grey" style="height: 35px; width: 35px"></div>
';
        $buffer .= $indent . '            </div>
';
        $buffer .= $indent . '            <div class="mr-4 w-75 bg-pulse-grey" style="height: 16px"></div>
';
        $buffer .= $indent . '            <div class="ml-auto bg-pulse-grey" style="width: 35px; height: 16px"></div>
';
        $buffer .= $indent . '        </div>
';
        $buffer .= $indent . '        <div class="bg-pulse-grey w-100" style="height: 16px"></div>
';
        $buffer .= $indent . '        <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
';
        $buffer .= $indent . '        <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
';
        $buffer .= $indent . '        <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
';
        $buffer .= $indent . '        <div class="bg-pulse-grey w-75 mt-2" style="height: 16px"></div>
';
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . '    <div class="d-flex flex-column p-2 bg-white rounded mb-2">
';
        $buffer .= $indent . '        <div class="d-flex align-items-center mb-2">
';
        $buffer .= $indent . '            <div class="mr-2">
';
        $buffer .= $indent . '                <div class="rounded-circle bg-pulse-grey" style="height: 35px; width: 35px"></div>
';
        $buffer .= $indent . '            </div>
';
        $buffer .= $indent . '            <div class="mr-4 w-75 bg-pulse-grey" style="height: 16px"></div>
';
        $buffer .= $indent . '            <div class="ml-auto bg-pulse-grey" style="width: 35px; height: 16px"></div>
';
        $buffer .= $indent . '        </div>
';
        $buffer .= $indent . '        <div class="bg-pulse-grey w-100" style="height: 16px"></div>
';
        $buffer .= $indent . '        <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
';
        $buffer .= $indent . '        <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
';
        $buffer .= $indent . '        <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
';
        $buffer .= $indent . '        <div class="bg-pulse-grey w-75 mt-2" style="height: 16px"></div>
';
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . '    <div class="d-flex flex-column p-2 bg-white rounded mb-2">
';
        $buffer .= $indent . '        <div class="d-flex align-items-center mb-2">
';
        $buffer .= $indent . '            <div class="mr-2">
';
        $buffer .= $indent . '                <div class="rounded-circle bg-pulse-grey" style="height: 35px; width: 35px"></div>
';
        $buffer .= $indent . '            </div>
';
        $buffer .= $indent . '            <div class="mr-4 w-75 bg-pulse-grey" style="height: 16px"></div>
';
        $buffer .= $indent . '            <div class="ml-auto bg-pulse-grey" style="width: 35px; height: 16px"></div>
';
        $buffer .= $indent . '        </div>
';
        $buffer .= $indent . '        <div class="bg-pulse-grey w-100" style="height: 16px"></div>
';
        $buffer .= $indent . '        <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
';
        $buffer .= $indent . '        <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
';
        $buffer .= $indent . '        <div class="bg-pulse-grey w-100 mt-2" style="height: 16px"></div>
';
        $buffer .= $indent . '        <div class="bg-pulse-grey w-75 mt-2" style="height: 16px"></div>
';
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . '</div>';

        return $buffer;
    }
}
