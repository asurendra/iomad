<?php
// ********** This file is generated DO NOT EDIT **********
$CFG->siteidentifier = 'unhsc4XB667wddyGLc3U0VJX5Dx8ChqAlocalhost';
$CFG->bootstraphash = 'c04bc82d6f04179cbe2718ce2e94c9c0';
// Only if the file is not stale and has not been defined.
if ($CFG->bootstraphash === hash_local_config_cache() && !defined('SYSCONTEXTID')) {
    define('SYSCONTEXTID', 1);
}
